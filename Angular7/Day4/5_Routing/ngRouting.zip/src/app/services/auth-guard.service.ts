import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router } from "@angular/router";
import { Injectable } from "@angular/core";
import { AuthenticationService } from "./authentication.service";

@Injectable()
export class AuthGaurdService implements CanActivate {
    constructor(private _router: Router,
        private _aService: AuthenticationService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (this._aService.getToken()) {
            return true;
        }

        this._router.navigate(['login'], { queryParams: { returnUrl: state.url } });
        return false;
    }
}